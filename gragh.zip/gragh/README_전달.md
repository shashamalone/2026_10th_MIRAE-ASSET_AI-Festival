# Graph(온톨로지/oxigraph) 환경 전달 패키지

작성일 2026-08-31 · 데이터 기준일(cutoff) **2026-08-24** · 총 33파일 86.5MB

---

## 0. 왜 보내는가 — 현재 원격 API의 문제

`http://40.82.145.44:8000` 실측(2026-08-31):

```
GET  /health                                  → graph_triples: 655,388  (적재 보고)
POST /db/sparql  SELECT ?s ?p ?o LIMIT 3      → row_count: 0   (HTTP 200, 에러 아님)
POST /db/sparql  타입 분포 GROUP BY            → row_count: 0
```

트리플이 65만 건이라고 보고하면서 **어떤 패턴도 매칭되지 않습니다.** 에러가 아니라 조용한 빈 결과라 원인이 밖에서는 보이지 않습니다.

또한 로컬 store는 **1,628,311 트리플**이라 원격(655,388)과 **내용 자체가 다릅니다.** 이 패키지로 동일 store를 재구축하면 차이가 해소됩니다.

### 함께 확인 요청드리는 3가지

1. `/db/sparql`이 조회하는 store가 `/health`의 `graph_triples`와 **같은 인스턴스**인가?
2. **named graph**를 쓰는가? 쓴다면 graph IRI는 무엇인가? (기본 그래프만 조회해서 0행일 가능성)
3. `/db/sparql`은 **PREFIX 선언 뒤에 개행이 없으면 400**을 냅니다.
   - 거부: `{"sparql":"PREFIX fp: <...#> SELECT ?s WHERE {...}"}` → `SELECT/ASK/CONSTRUCT/DESCRIBE만 허용합니다`
   - 통과: PREFIX 줄 끝에 `\n` 이 있으면 정상
   - 우리 쪽(`src/tools/graph.py`)은 PREFIX 블록을 정규식으로 제거한 뒤 첫 키워드를 판정합니다. 서버도 동일하게 맞춰 주셔야 에이전트가 생성하는 질의 상당수가 거부되지 않습니다.

---

## 1. 재현 절차 (권장 — 이것만 하면 됩니다)

```bash
pip install pyoxigraph rdflib          # requirements.txt 참고
python3 src/kb/build_graph.py          # ontology/*.ttl 10개 → artifacts/oxigraph/
```

**성공 판정** — 생성된 `artifacts/oxigraph/manifest.json`이 동봉한
`oxigraph_manifest.expected.json`과 일치해야 합니다:

```json
{
  "triple_count": 1628311,
  "future_as_of_count": 0,
  "cutoff": "2026-08-24",
  "excluded_future_nodes": 0
}
```

`triple_count`가 다르면 TTL 일부가 누락된 것입니다. `CHECKSUMS.txt`로 대조해 주세요.

### 동작 확인 질의 3개 (재구축 후 실행 시 아래 결과가 나와야 정상)

```sparql
PREFIX fp: <http://mafest.ai/product#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
SELECT (COUNT(?s) AS ?n) WHERE { ?s rdf:type fp:ETF }
```
→ **7,207**

```sparql
PREFIX fp: <http://mafest.ai/product#>
SELECT (COUNT(DISTINCT ?c) AS ?n) WHERE { ?c fp:hasSubsidiary ?r }
```
→ 자회사 관계 보유 기업 (전체 hasSubsidiary 트리플 **30,097**)

```sparql
PREFIX fp: <http://mafest.ai/product#>
SELECT ?name WHERE { ?p fp:productShortName "KODEX 200" ; fp:productName ?name }
```
→ `삼성 KODEX200 증권상장지수투자신탁[주식]`

---

## 2. 파일 목록

### ontology/ — 그래프 재구축 입력 (10파일, 85.4MB) ★ 핵심

| 파일 | 크기 | 구분 | 비고 |
|---|---|---|---|
| `common.ttl` | 0.1MB | TBox | 공통 스키마. **DatatypeProperty에 `fp:sourceTable`/`fp:sourceColumn` 애노테이션** — 답변 근거로 인용됨 |
| `bond_kr.ttl` | 0.03MB | TBox | 채권 |
| `etf_kr.ttl` | 0.03MB | TBox | 국내 ETF |
| `etf_gl.ttl` | 0.02MB | TBox | 해외 ETF |
| `fund_pub.ttl` | 0.03MB | TBox | 공모펀드 |
| `instances_bond_kr.ttl` | 11.9MB | ABox | **git 미포함(gitignore)** |
| `instances_etf_kr.ttl` | 31.7MB | ABox | **git 미포함** |
| `instances_etf_gl.ttl` | 2.1MB | ABox | **git 미포함** |
| `instances_fund_pub.ttl` | 11.5MB | ABox | **git 미포함** |
| `instances_company.ttl` | 28.0MB | ABox | **git 미포함** |


### src/ — 빌드·조회 코드

| 파일 | 역할 |
|---|---|
| `src/kb/build_graph.py` | TTL 10개 → persistent oxigraph Store 빌드 + cutoff 검증 |
| `src/tools/graph.py` | 읽기 전용 SPARQL 게이트. **SELECT/ASK만 허용**, MAX_ROWS 10,000, PREFIX 제거 후 키워드 판정 |
| `src/config.py` | 경로·모델 상수 (`ARTIFACTS`, cutoff 등) |

### EDA/ — 데이터 분석 근거 (3.4MB)

| 파일 | 내용 |
|---|---|
| `EDA_REPORT_0824.md` | **08-24 배포본 실측 분석** (현행 기준) |
| `EDA_REPORT_0711.md` | 07-11 배포본 (참고) |
| `01_bond_kr.ipynb` ~ `05_linkage.ipynb` | 도메인별 EDA 노트북 (실행 출력 포함) |
| `src/*.py` | 위 노트북의 jupytext 소스 |

### metadata/ · 기타

| 파일 | 내용 |
|---|---|
| `metadata/schema_bindings.json` | logical ↔ physical 스키마 매핑 |
| `metadata/business_rules.json` | filter/join/unit/value 규칙 |
| `metadata/query_execution_rules.json` | 질의 실행 규칙 |
| `requirements.txt` | 의존성 (pyoxigraph, rdflib 등) |
| `AGENTS.md` | **데이터 함정·절대 규칙** — 아래 3절 요약 참고 |
| `CHECKSUMS.txt` | 전 파일 sha256(앞 16자) + 바이트 |
| `artifacts/manifest.json` | 빌드 성공 판정 기준값 |


---

## 4. 환경

| 항목 | 값 |
|---|---|
| pyoxigraph | **0.5.9** (store 포맷이 버전에 묶입니다) |
| Python | 3.10+ |
| store 크기 | 재구축 시 약 219MB |
| 빌드 시간 | 수 분 (bulk_load) |

빌드가 실패하거나 `triple_count`가 다르면 완성된 store 디렉터리(219MB)를 별도 전달할 수 있습니다. 연락 주세요.
